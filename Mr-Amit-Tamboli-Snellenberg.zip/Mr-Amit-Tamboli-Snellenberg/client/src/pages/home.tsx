import { animate, motion, AnimatePresence, useScroll, useTransform, useInView, useMotionValue } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import MagneticButton from "@/components/ui/magnetic-button";
import Preloader from "@/components/ui/preloader";
import { ArrowDown, ArrowUpRight, ChevronLeft, ChevronRight, Mail, Phone, Linkedin } from "lucide-react";

type ExperienceRole = { title: string; period: string; promoted?: boolean };
type Experience = {
  company: string;
  period: string;
  note: string;
} & (
  | { role: string; roles?: never }
  | { role?: never; roles: ExperienceRole[] }
);

const experiences: Experience[] = [
  { company: "Solitario Lab Grown Limited", role: "Store Manager", period: "October 2026 – Present", note: "Leading store operations and customer experience in lab-grown jewellery." },
  {
    company: "Palmonas",
    period: "May 2025 – August 2026",
    roles: [
      { title: "Assistant Store Manager", period: "April 2026 – August 2026", promoted: true },
      { title: "Senior Sales Executive", period: "May 2025 – March 2026" },
    ],
    note: "Promoted from Senior Sales Executive to Assistant Store Manager, supporting customer experience and store operations.",
  },
  { company: "Urban Ladder – Reliance Retail", role: "Senior Design Consultant", period: "April 2024 – April 2025", note: "Guided residential and office customers through complete design journeys." },
  { company: "Studio Pepperfry", role: "Home Consultant", period: "April 2023 – February 2024", note: "Connected customers with considered home solutions through consultative selling." },
  { company: "Crafted Marbles", role: "Business Development Executive", period: "November 2022 – April 2023", note: "Handled lead generation, client meetings and end-to-end product conversations." },
  { company: "Riyyog", role: "Social Media Marketing Intern", period: "August 2022 – November 2023", note: "Supported social media marketing and audience-facing communication." },
  { company: "Retailio", role: "Client Relationship Executive", period: "September 2021 – August 2022", note: "Built the foundations of customer relationship management and follow-up." },
];

const process = [
  ["01", "UNDERSTAND", "Listen before selling."],
  ["02", "CONNECT", "Build trust before pushing."],
  ["03", "SOLVE", "Identify the right solution for the actual need."],
  ["04", "CONVERT", "Turn confidence into action."],
  ["05", "DELIVER", "Create an experience worth returning to."],
];

const impact = [
  ["19L+", "Highest monthly personal sales"],
  ["30L+", "Gold sales generated in less than 12 months"],
  ["1CR+", "Demi-fine jewellery sales contribution"],
  ["7.9L", "Highest single bill at Urban Ladder"],
  ["25L", "Highest monthly sales at Pepperfry"],
];

const expertise = ["Retail Operations", "Store Management", "Sales", "Business Development", "Customer Relationship Management", "Customer Experience", "Consultative Selling", "Upselling & Cross-selling", "Visual Merchandising", "Team Coordination", "Digital Marketing"];
const certifications = {
  MARKETING: ["Google Fundamentals of Digital Marketing", "IIDE Digital Marketing Fundamentals", "Udemy Instagram Marketing"],
  TECHNOLOGY: ["CompTIA Certified Network Administrator", "CompTIA IT Fundamentals", "Certified Secure Computer User"],
  "PROBLEM SOLVING": ["Udemy Design Thinking"],
};

function Reveal({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-70px" }} transition={{ duration: .65, ease: [0.33, 1, 0.68, 1] }} className={className}>{children}</motion.div>;
}

function SectionLabel({ number, children, teal = false }: { number: string; children: React.ReactNode; teal?: boolean }) {
  return <span className={`section-label ${teal ? "label-teal" : ""}`}><i />{number} / {children}</span>;
}

function Marquee() {
  return <div className="marquee" aria-hidden="true"><div className="marquee-track">{[...Array(3)].map((_, i) => <span key={i}>CONVERSATIONS — RELATIONSHIPS — CONVERSIONS — RESULTS —</span>)}</div></div>;
}

function ExperienceItem({ exp, index }: { exp: Experience; index: number }) {
  return <Reveal className="experience-item">
    <div className="experience-index">0{index + 1}</div>
    <div className="experience-main">
      <div className="experience-meta"><span>{exp.period}</span></div>
      <h3>{exp.company}</h3>
      {exp.roles ? <div className="experience-role-history">
        {exp.roles.map((role) => <div className="experience-role-entry" key={role.title}>
          <span className="experience-role">{role.title}</span>
          <span className="experience-role-period">{role.period}</span>
          {role.promoted && <b>PROMOTED</b>}
        </div>)}
      </div> : <p className="experience-role">{exp.role}</p>}
    </div>
    <p className="experience-note">{exp.note}</p>
  </Reveal>;
}

function ImpactNumber({ value }: { value: string }) {
  const numberRef = useRef<HTMLElement | null>(null);
  const isInView = useInView(numberRef, { once: true, margin: "-70px" });
  const count = useMotionValue(0);
  const match = /^(\d+(?:\.\d+)?)(.*)$/.exec(value);
  const isNumeric = match !== null;
  const rawTarget = match?.[1] ?? "0";
  const suffix = match?.[2] ?? "";
  const target = Number(rawTarget);
  const precision = rawTarget.includes(".") ? 1 : 0;
  const displayValue = useTransform(count, (current) => `${current.toFixed(precision)}${suffix}`);

  useEffect(() => {
    if (!isInView) return;
    if (!isNumeric || !Number.isFinite(target)) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      count.set(target);
      return;
    }

    const controls = animate(count, target, {
      duration: 0.85,
      ease: [0.33, 1, 0.68, 1],
    });
    return () => controls.stop();
  }, [count, isInView, isNumeric, target]);

  return <motion.strong ref={numberRef} aria-label={value}>{match ? displayValue : value}</motion.strong>;
}

export default function Home() {
  const [loading, setLoading] = useState(true);
  const [processIndex, setProcessIndex] = useState(0);
  const { scrollY } = useScroll();
  const heroTextY = useTransform(scrollY, [0, 500], [0, -80]);
  const viewportHeight = typeof window === "undefined" ? 800 : window.innerHeight;
  const heroTextOpacity = useTransform(scrollY, [0, viewportHeight * 0.94, viewportHeight * 1.0], [1, 1, 0]);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const move = (e: MouseEvent) => rootRef.current?.style.setProperty("--mouse-x", `${e.clientX}px`);
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);

  return <div ref={rootRef} className="portfolio">
    <AnimatePresence>{loading && <Preloader onComplete={() => setLoading(false)} />}</AnimatePresence>
    {!loading && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
      <Header />
      <main>
        <section className="hero">
          <motion.div className="hero-content" style={{ y: heroTextY, opacity: heroTextOpacity }}>
            <Reveal>
              <h1>MR. AMIT <span>TAMBOLI</span><b>.</b></h1>
               <span className="eyebrow burgundy">STORE MANAGER <em>·</em> RETAIL SALES <em>·</em> BUSINESS DEVELOPMENT</span>
              <div className="hero-bottom">
                <div><h2>TURNING CONVERSATIONS<br />INTO <span>CONVERSIONS.</span></h2><p>Building relationships, understanding people and turning meaningful interactions into business results.</p></div>
                <div className="hero-actions"><MagneticButton><a className="btn btn-primary" href="#experience">VIEW EXPERIENCE <ArrowDown size={15} /></a></MagneticButton><MagneticButton><a className="btn btn-outline" href="#contact">START A CONVERSATION <ArrowUpRight size={15} /></a></MagneticButton></div>
              </div>
            </Reveal>
          </motion.div>
          <div className="scroll-cue"><span>SCROLL TO EXPLORE</span><ArrowDown size={15} /></div>
        </section>

        <Marquee />

        <section className="statement section-shell">
          <SectionLabel number="01" teal>PERSONAL PHILOSOPHY</SectionLabel>
          <Reveal><p>I DON'T BELIEVE EVERY<br />CONVERSATION SHOULD<br />END IN A <span className="teal-text">SALE.</span></p><p className="statement-reveal">BUT EVERY GOOD SALE<br />BEGINS WITH <span className="burgundy-text">ONE.</span></p></Reveal>
        </section>

        <section className="approach section-shell">
          <div className="section-heading"><SectionLabel number="02">HOW I WORK</SectionLabel><h2>Building <span>relationships.</span><br />Delivering results.</h2></div>
          <div className="process-list">{process.map(([n, title, desc], i) => <div className="process-row-shell" key={n}><MagneticButton><motion.button onClick={() => setProcessIndex(i)} className={`process-row ${processIndex === i ? "active" : ""}`}><span>{n}</span><strong>{title}</strong><small>{desc}</small><ArrowUpRight size={17} /></motion.button></MagneticButton></div>)}</div>
        </section>

        <section className="impact section-shell">
          <SectionLabel number="03">SELECTED IMPACT</SectionLabel>
          <div className="impact-intro"><h2>Results that<br /><span>stay with you.</span></h2><p>Selected milestones from a career built around understanding the customer, taking ownership and executing with intent.</p></div>
          <div className="impact-grid">{impact.map(([num, label]) => <Reveal key={num} className="impact-item"><ImpactNumber value={num} /><span>{label}</span></Reveal>)}</div>
        </section>

        <section id="experience" className="experience section-shell">
          <div className="section-heading"><SectionLabel number="04" teal>CAREER JOURNEY</SectionLabel><h2>From customer conversations<br /><span>to store leadership.</span></h2><p>A career shaped across customer relationships, marketing, business development, premium retail and store operations.</p></div>
          <div className="experience-list">{experiences.map((exp, i) => <ExperienceItem key={`${exp.company}-${exp.role}`} exp={exp} index={i} />)}</div>
        </section>

        <section className="education section-shell">
          <div><SectionLabel number="05">EDUCATION</SectionLabel><div className="education-list"><Reveal><span>PG DIPLOMA IN MANAGEMENT, MARKETING</span><h3>Welingkar</h3><small>2023 – Ongoing</small></Reveal><Reveal><span>BACHELOR OF MANAGEMENT STUDIES, MARKETING</span><h3>R.A.D.A.V. College Mumbai</h3><small>Completed 2023</small></Reveal><Reveal><span>JUNIOR COLLEGE (12TH)</span><h3>K.V.K Sarvajanik Jr. College</h3><small>Commerce (HSC) · Completed 2020</small></Reveal><Reveal><span>SCHOOL (10TH)</span><h3>Shivneri School</h3><small>SSC</small></Reveal></div></div>
          <div className="certs"><SectionLabel number="06" teal>CERTIFICATIONS & SKILLS</SectionLabel>{Object.entries(certifications).map(([group, items]) => <div className="cert-group" key={group}><b>{group}</b>{items.map(item => <p key={item}>{item}</p>)}</div>)}<div className="expertise"><b>AREAS OF EXPERTISE</b>{expertise.map(x => <span key={x}>{x}</span>)}</div></div>
        </section>

        <section className="beyond section-shell"><SectionLabel number="07" teal>BEYOND THE RESUME</SectionLabel><Reveal><h2>Curious about how<br />people <span>think.</span></h2><p>Interested in why they choose. Always looking for a better way to sell, communicate and execute.</p></Reveal></section>

        <section id="contact" className="cta section-shell"><SectionLabel number="08">NEXT CONVERSATION</SectionLabel><Reveal><h2>LET'S TURN A<br />CONVERSATION INTO<br /><span>AN OPPORTUNITY.</span></h2><div className="cta-actions"><MagneticButton><a className="btn btn-primary" href="mailto:2504amit@gmail.com">START A CONVERSATION <ArrowUpRight size={16} /></a></MagneticButton><MagneticButton><a className="btn btn-outline" href="https://linkedin.com/in/amit-dayanand-tamboli" target="_blank" rel="noreferrer">VIEW LINKEDIN <ArrowUpRight size={16} /></a></MagneticButton></div><div className="contact-details"><MagneticButton><a href="mailto:2504amit@gmail.com"><Mail size={16} />2504amit@gmail.com</a></MagneticButton><MagneticButton><a href="tel:+919075140431"><Phone size={16} />+91 90751 40431</a></MagneticButton><MagneticButton><a href="https://linkedin.com/in/amit-dayanand-tamboli" target="_blank" rel="noreferrer"><Linkedin size={16} />linkedin.com/in/amit-dayanand-tamboli</a></MagneticButton></div></Reveal></section>
      </main>
      <Footer />
    </motion.div>}
  </div>;
}