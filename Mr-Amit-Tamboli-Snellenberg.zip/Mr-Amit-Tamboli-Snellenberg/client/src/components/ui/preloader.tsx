import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

const words = [
  { text: "Hello.", duration: 600 },
  { text: "Amit Tamboli", duration: 800 }
];

export default function Preloader({ onComplete }: { onComplete: () => void }) {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (index === words.length) {
      setTimeout(onComplete, 600);
      return;
    }

    const timer = setTimeout(() => {
      setIndex((prev) => prev + 1);
    }, words[index].duration);
    
    return () => clearTimeout(timer);
  }, [index, onComplete]);

  return (
    <div className="fixed inset-0 z-[100] pointer-events-none">
      <motion.div
        initial={{ y: 0 }}
        exit={{ y: "-100%" }}
        transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1], delay: 0.2 }}
        className="absolute inset-0 z-10 flex items-center justify-center bg-black text-white"
      >
        <div className="relative overflow-hidden h-20 flex items-center justify-center w-full px-4">
          <AnimatePresence mode="wait">
            <motion.p
              key={index === words.length ? "done" : index}
              initial={{ y: 80 }}
              animate={{ y: 0 }}
              exit={{ y: -80 }}
              transition={{ 
                duration: 0.4, 
                ease: [0.33, 1, 0.68, 1] 
              }}
              className="text-3xl md:text-5xl font-display font-bold absolute text-center w-full tracking-tighter"
            >
              {index < words.length && (
                <>
                  <span className="inline-block w-3 h-3 bg-white rounded-none mr-4 align-middle" />
                  {words[index].text}
                </>
              )}
            </motion.p>
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
