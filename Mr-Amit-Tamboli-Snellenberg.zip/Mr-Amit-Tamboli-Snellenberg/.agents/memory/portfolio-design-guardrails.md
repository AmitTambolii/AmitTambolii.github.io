---
name: Portfolio design guardrails
description: Durable visual and interaction constraints for Amit Tamboli's portfolio.
---

Keep the existing portfolio and its core visual identity intact. Do not rebuild it or change its dark luxury aesthetic, animation system, navigation structure, or overall design language unless the user explicitly asks.

**Why:** the user provided this as a standing scope rule for the portfolio.

**How to apply:** limit future changes to the requested section or behavior and preserve the established design and interaction patterns.
