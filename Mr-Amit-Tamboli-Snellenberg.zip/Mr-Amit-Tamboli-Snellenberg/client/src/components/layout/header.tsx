import { Link, useLocation } from "wouter";
import MagneticButton from "@/components/ui/magnetic-button";
import { Home as HomeIcon, Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Header() {
  const [, setLocation] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > window.innerHeight * 0.96);
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleHomeClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsMenuOpen(false);
    if (window.location.pathname === "/") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      setLocation("/");
      setTimeout(() => window.scrollTo({ top: 0, behavior: "smooth" }), 100);
    }
  };

  const scrollToSection = (id: string) => {
    setIsMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50 p-4 md:p-10 flex justify-between items-center pointer-events-none">
      <div className={`pointer-events-auto header-identity ${isScrolled ? "header-identity-visible" : ""}`}>
        <div className="header-identity-content" aria-label="Amit Tamboli identity">
          <span className="w-2 h-2 md:w-2.5 md:h-2.5 bg-primary rounded-none shadow-[0_0_10px_rgba(122,38,51,0.5)]" />
          <span>
            <span className="header-name">MR. AMIT TAMBOLI.</span>
            <span className="header-headline">TURNING CONVERSATIONS INTO CONVERSIONS.</span>
          </span>
        </div>
      </div>

      <nav className="pointer-events-auto flex items-center gap-8">
        <div className="hidden md:flex gap-4 p-2 bg-black/40 backdrop-blur-md rounded-none border-b border-white/20">
          <MagneticButton>
            <button 
              onClick={handleHomeClick}
              className="px-6 py-2 text-white hover:text-primary transition-colors text-sm font-bold font-mono uppercase tracking-widest block cursor-pointer"
            >
              <HomeIcon className="mx-auto h-4 w-4" aria-hidden="true" />
              <span className="sr-only">Home</span>
            </button>
          </MagneticButton>
          <MagneticButton>
          <button onClick={() => scrollToSection('experience')} className="px-6 py-2 text-white hover:text-primary transition-colors text-base font-bold font-mono uppercase tracking-widest cursor-pointer block">Experience</button>
          </MagneticButton>
          <MagneticButton>
          <button onClick={() => scrollToSection('contact')} className="px-6 py-2 text-white hover:text-primary transition-colors text-base font-bold font-mono uppercase tracking-widest cursor-pointer block">Contact</button>
          </MagneticButton>
        </div>
        
        <div className="md:hidden">
          <MagneticButton>
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="w-12 h-12 bg-black/80 border border-white/10 rounded-full flex items-center justify-center backdrop-blur-md cursor-pointer text-white"
            >
               {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </MagneticButton>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: "100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed inset-0 bg-black z-40 pointer-events-auto flex flex-col justify-center p-8"
          >
            <div className="flex flex-col gap-8">
              <MagneticButton><button onClick={handleHomeClick} className="text-4xl font-display font-bold tracking-tighter text-left hover:text-gray-300 transition-colors">Home</button></MagneticButton>
              <MagneticButton><button onClick={() => scrollToSection('experience')} className="text-4xl font-display font-bold tracking-tighter text-left hover:text-gray-300 transition-colors">Experience</button></MagneticButton>
              <MagneticButton><button onClick={() => scrollToSection('contact')} className="text-4xl font-display font-bold tracking-tighter text-left hover:text-gray-300 transition-colors">Contact</button></MagneticButton>
            </div>
            
            <div className="mt-20 pt-8 border-t border-white/10">
              <p className="text-white font-mono text-base uppercase tracking-widest mb-4">Socials</p>
              <div className="flex gap-6">
                <MagneticButton><a href="https://linkedin.com/in/amit-dayanand-tamboli" target="_blank" rel="noopener noreferrer" className="text-xl hover:text-gray-300 transition-colors">LinkedIn</a></MagneticButton>
                <MagneticButton><a href="mailto:2504amit@gmail.com" className="text-xl hover:text-gray-300 transition-colors">Email</a></MagneticButton>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
