---
name: Git provider write access
description: Distinguishes an attached GitHub OAuth connection from working direct Git CLI authentication.
---

Do not assume a connected GitHub account grants Git CLI write access; verify a real push to a non-deploying branch before reporting a transfer as complete.

**Why:** In this workspace, the GitHub connection reported healthy, but HTTPS and SSH pushes were rejected.

**How to apply:** For repository transfers, use the Replit Git pane or another authorized write path when CLI authentication fails, and confirm the remote branch ref before reporting success.
