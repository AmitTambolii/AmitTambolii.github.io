import MagneticButton from "@/components/ui/magnetic-button";
import { Linkedin, Mail, Phone } from "lucide-react";
import portrait from "@assets/amit-tamboli-footer.webp";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-transparent text-white pt-16 md:pt-32 px-6 md:px-12 relative overflow-hidden border-t border-primary">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 md:gap-12">
          <div className="flex items-center gap-4 md:gap-6">
            <img
              src={portrait}
              alt="Portrait of Amit Tamboli"
              width={1024}
              height={1024}
              loading="lazy"
              className="footer-portrait h-28 w-24 md:h-36 md:w-28 shrink-0 border border-white/15 object-cover"
            />
            <div className="border-l-4 border-primary pl-4 md:pl-6 text-left">
              <h3 className="text-xl md:text-2xl font-display font-bold tracking-tighter mb-2 md:mb-3">Amit Tamboli</h3>
              <p className="text-white text-base font-semibold uppercase tracking-[0.12em]">Store Manager</p>
              <p className="footer-specialties mt-2">Retail Sales | Business Development | Customer Experience</p>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-4 md:gap-6 text-base font-bold font-mono uppercase tracking-widest text-white">
            <MagneticButton>
              <a href="mailto:2504amit@gmail.com" className="hover:text-primary transition-colors bg-white/5 px-4 py-3 border border-white/10">Email</a>
            </MagneticButton>
            <MagneticButton>
              <a href="https://linkedin.com/in/amit-dayanand-tamboli" target="_blank" rel="noreferrer" className="hover:text-primary transition-colors bg-white/5 px-4 py-3 border border-white/10">LinkedIn</a>
            </MagneticButton>
            <MagneticButton>
              <a href="tel:+919075140431" className="hover:text-primary transition-colors bg-white/5 px-4 py-3 border border-white/10">Call</a>
            </MagneticButton>
          </div>
        </div>

        <div className="group mt-12 md:mt-20 relative pt-8 md:pt-12 pb-24 md:pb-40 w-[100vw] left-1/2 -translate-x-1/2 px-6 md:px-12 border-t border-white/5">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center text-base font-mono text-white gap-4 relative z-20 pointer-events-none">
            <p className="pointer-events-auto z-30">© {currentYear} • DESIGNED FOR IMPACT</p>
            <p className="pointer-events-auto z-30">PUNE, INDIA — WORLDWIDE</p>
          </div>
          
          <div className="absolute bottom-0 left-0 w-full select-none text-center cursor-default z-10 overflow-hidden pointer-events-none flex items-end justify-center h-full">
            <h1 className="text-[15vw] md:text-[12vw] font-display font-bold leading-none uppercase text-white/5 flex items-center justify-center gap-4 md:gap-8 whitespace-nowrap translate-y-[15%]">
              <span className="opacity-0 group-hover:opacity-100 transition-all duration-[1.5s] ease-[cubic-bezier(0.16,1,0.3,1)] blur-2xl group-hover:blur-none translate-y-32 group-hover:translate-y-0 inline-block">Mr.</span>
              <span className="opacity-0 group-hover:opacity-100 transition-all duration-[1.5s] ease-[cubic-bezier(0.16,1,0.3,1)] delay-[150ms] blur-2xl group-hover:blur-none translate-y-32 group-hover:translate-y-0 inline-block">Amit</span>
              <span className="opacity-0 group-hover:opacity-100 transition-all duration-[1.5s] ease-[cubic-bezier(0.16,1,0.3,1)] delay-[300ms] blur-2xl group-hover:blur-none translate-y-32 group-hover:translate-y-0 inline-block">Tamboli</span>
            </h1>
          </div>
        </div>
      </div>
    </footer>
  );
}
